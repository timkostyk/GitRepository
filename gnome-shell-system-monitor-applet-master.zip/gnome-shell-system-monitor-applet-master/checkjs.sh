#!/bin/bash
# Install eslint with:
#   sudo apt-get install npm && sudo npm install -g eslint
eslint system-monitor@paradoxxx.zero.gmail.com
